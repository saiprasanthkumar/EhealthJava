import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthGuardService } from './auth-guard.service';
import { CitizenComponent } from './citizen/citizen.component';
import { CityComponent } from './city/city.component';
import { ComplaintComponent } from './complaint/complaint.component';
import { HomeComponent } from './home/home.component';
import { JobComponent } from './job/job.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';



const routes: Routes = [  
  { path: '', component: LoginComponent } , 
  { path: 'signup', component: SignupComponent },
  { path: 'home', component: HomeComponent , canActivate: [AuthGuardService] },
  { path: 'city', component: CityComponent  , canActivate: [AuthGuardService] } ,
  { path: 'job', component: JobComponent , canActivate: [AuthGuardService] }, 
  { path: 'complaint', component: ComplaintComponent , canActivate: [AuthGuardService] }, 
  { path: 'citizen', component: CitizenComponent , canActivate: [AuthGuardService] }];
  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
