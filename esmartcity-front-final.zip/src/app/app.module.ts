import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { MatCardModule, MatDialogModule, MatRadioModule, MatTableModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CityComponent } from './city/city.component';
import { JobComponent } from './job/job.component';
import { ComplaintComponent, DialogContentExampleDialog } from './complaint/complaint.component';
import { CitizenComponent } from './citizen/citizen.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    CityComponent,
    JobComponent,
    ComplaintComponent,
    CitizenComponent,
    DialogContentExampleDialog
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NoopAnimationsModule,
    MatCardModule,
    MatTableModule,
    HttpClientModule,
    MatRadioModule,
    FormsModule,
    MatDialogModule,
    MatCardModule
  ],
  providers: [],
  entryComponents: [
    DialogContentExampleDialog
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
